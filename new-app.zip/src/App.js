var element = React.createElement('h1', null, 'fsdfsdfsd');
ReactDOM.render(element, document.getElementById('root'));